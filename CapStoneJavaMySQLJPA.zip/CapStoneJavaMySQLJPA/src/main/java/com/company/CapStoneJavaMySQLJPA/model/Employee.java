package com.company.CapStoneJavaMySQLJPA.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="employee")

public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    //id of the employee
    @Column(name = "id")
    @NotNull
    private Integer id;

    //name of the employee
    @Column(name = "employee_name")
    @NotNull
    private String employeeName;

    //title (i.e. "CEO" or "Janitor"
    @Column(name = "title")
    @NotNull
    private String title;

    //with more time I would have preferred to use the Date type here, but as that's not something we've run into (nor did I need to perform any functions with the date hired) I elected to go with a string for right now.
    @Column(name = "date_hired")
    @NotNull
    private String dateHired;

    //id number of the company they are assigned to
    @Column(name = "company_id")
    @NotNull
    private Integer companyId;

    //time they are allowed to enter the building
    @Column(name = "starts_work")
    @NotNull
    private Integer startsWork;

    //time they are required to leave the building by
    @Column(name = "ends_work")
    @NotNull
    private Integer endsWork;

    //accessLevel for the building.  level one denotes general, level 2 denotes access to the manager rooms of 6 if applicable, level 3 is for the systems admin on 6
    @Column(name = "access_level")
    @NotNull
    private Integer accessLevel;

    //mapping employees to company for pulling custom queries (incomplete as custom queries still building)
    @OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="employee_id")
    private Set<Company> employeesByCompany;

    //constructor
    public Employee() {

    }
//getters and setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDateHired() {
        return dateHired;
    }

    public void setDateHired(String dateHired) {
        this.dateHired = dateHired;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        int max = 7;
        int min = 1;
        int range = max - min + 1;

        // generate random numbers within 1 to 10
        for (int i = 0; i < 7; i++) {
            int rand = (int) (Math.random() * range) + min;

            this.companyId = companyId;
        }
    }

    public Integer getStartsWork() {
        return startsWork;
    }

    public void setStartsWork(Integer startsWork) {
        this.startsWork = startsWork;
    }

    public Integer getEndsWork() {
        return endsWork;
    }

    public void setEndsWork(Integer endsWork) {
        this.endsWork = endsWork;
    }

    public Integer getAccessLevel() {
        return accessLevel;
    }

    public void setAccessLevel(Integer accessLevel) {
        this.accessLevel = accessLevel;
    }

    //@ManyToOne
}
