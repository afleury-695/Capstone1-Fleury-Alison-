package com.company.CapStoneJavaMySQLJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapStoneJavaMySqljpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapStoneJavaMySqljpaApplication.class, args);
	}

}
