package com.company.CapStoneJavaMySQLJPA.ControllersResource;

import com.company.CapStoneJavaMySQLJPA.Service.Service;
import com.company.CapStoneJavaMySQLJPA.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
//@RequestMapping(value = "/rest/users")
public class EmployeeController {
    @Autowired


    Service service;


    //adds a new employee
    @RequestMapping(value="/employeeadd", method= RequestMethod.POST)
    public Employee addEmployee(@RequestBody @Valid Employee employee) {
        service.addEmployee(employee);
        return employee;
    }

    //returns all employees
    @RequestMapping(value = "/employees", method = RequestMethod.GET)
    public List<Employee> findAll() {
        return service.findAll();
    }

    //finds an employee by ID
    @RequestMapping(value = "/employee/{id}", method = RequestMethod.GET)
    public Employee getEmployeeById(@PathVariable Integer id) {
        return service.getEmployeeById(id);
    }

    /*to promote or demote, adjust the accessLevel from lowest (1) to highest (3) using PUT.  I chose to use accessLevel to increase or to
    decrease promotion/demotion, as that was the applicable variable.  You could also change their title here though, if you wanted to promote
    or demote them by both title and access level.*/
    @RequestMapping(value = "/employeeaccess/{id}", method = RequestMethod.PUT)
    public void updateEmployee(@RequestBody @Valid Employee employee, @PathVariable Integer id) {
        service.updateEmployee(employee, id);
    }

    //deletes employee
    @RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
    public void deleteEmployee(@PathVariable int id) {
        service.deleteEmployee(id);
    }

    /* @RequestMapping(value = "/employeesbycompany/{companyId}", method = RequestMethod.GET)
    public Employee findAll(@PathVariable Integer companyId) { return service.findAll(companyId); }


     */
    }




