package com.company.CapStoneJavaMySQLJPA.ControllersResource;

import com.company.CapStoneJavaMySQLJPA.Service.CompanyService;
import com.company.CapStoneJavaMySQLJPA.Service.Service;
import com.company.CapStoneJavaMySQLJPA.model.Company;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class CompanyController {
    @Autowired

    private CompanyService service;

    //add a company to the current list of companies
    @RequestMapping(value="/companyadd", method= RequestMethod.POST)
    public Company addCompany(@RequestBody @Valid Company company) {
        service.addCompany(company);
        return company;
    }

    //find all companies currently listed
    @RequestMapping(value = "/companies", method = RequestMethod.GET)
    public List<Company> findAll() {
        return service.findAll();
    }

    //find a company by the company ID
    @RequestMapping(value = "/company/{id}", method = RequestMethod.GET)
    public Company getCompanyById(@PathVariable Integer companyId) {
        return service.getCompanyById(companyId);
    }

    //delete a company by the companyId
    @RequestMapping(value = "/companydelete/{id}", method = RequestMethod.DELETE)
    public void deleteById(@PathVariable Integer companyId) {
        service.deleteById(companyId);
    }

}

