package com.company.CapStoneJavaMySQLJPA.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.company.CapStoneJavaMySQLJPA.model.Timecard;

public interface TimecardRepository extends JpaRepository<Timecard, Integer> {
}
