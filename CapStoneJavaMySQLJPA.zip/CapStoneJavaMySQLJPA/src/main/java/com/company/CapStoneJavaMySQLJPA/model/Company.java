package com.company.CapStoneJavaMySQLJPA.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="company")

public class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    @Column(name= "company_id")
    @NotNull
    private Integer companyId;

    @Column(name ="company_name")
    @NotNull
    private String companyName;

    @Column(name = "floors_occupied")
    @NotNull
   private String floorsOccupied;

    //manytoone mapping to go alongside the one to many in Employee (methods for custom queries would be the next step to working alongside this, as I said in my presentation those did not get completed at this stage but are in the works)
    @ManyToOne
    private Employee employee;

    //constructor
    public Company() {

    }

    //getters and setters
    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getFloorsOccupied() {
        return floorsOccupied;
    }

    public void setFloorsOccupied(String floorsOccupied) {
        this.floorsOccupied = floorsOccupied;
    }

}
