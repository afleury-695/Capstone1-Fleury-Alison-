package com.company.CapStoneJavaMySQLJPA.Service;


import com.company.CapStoneJavaMySQLJPA.Repository.EmployeeRepository;
import com.company.CapStoneJavaMySQLJPA.model.Employee;

//this was added to see if it helped.  It doesn't seem to
import com.company.CapStoneJavaMySQLJPA.ControllersResource.EmployeeController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Service {
    @Autowired
    private EmployeeRepository employeeRepo;

    //adds employee
    public Employee addEmployee(Employee employee) {
        employeeRepo.save(employee);
        return employee;
    }

    //returns all employees
    public List<Employee> findAll() {
        return employeeRepo.findAll();
    }

    //returns specific employee by ID
    public Employee getEmployeeById(int id) {
        return employeeRepo.getOne(id);
    }

    //updates the employee information
    public void updateEmployee(Employee employee, int id) {
        employeeRepo.save(employee);
    }

    //deletes an employee by the ID entered
    public void deleteEmployee(int id) {
        employeeRepo.deleteById(id);
    }

}
