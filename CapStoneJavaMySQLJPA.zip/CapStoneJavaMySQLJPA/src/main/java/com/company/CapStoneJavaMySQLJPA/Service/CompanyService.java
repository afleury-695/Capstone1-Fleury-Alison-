package com.company.CapStoneJavaMySQLJPA.Service;

import com.company.CapStoneJavaMySQLJPA.Repository.CompanyRepository;
import com.company.CapStoneJavaMySQLJPA.model.Company;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

//repository to hold all companies
@Component
public class CompanyService {
    @Autowired

    private CompanyRepository companyRepo;

    //POST add a company
    public Company addCompany(Company company) {
        companyRepo.save(company);
        return company;
    }

    //GET list all companies
    public List<Company> findAll() {
        return companyRepo.findAll();
    }

    //GET a company by companyID
    public Company getCompanyById(Integer companyId) {
        return companyRepo.getOne(companyId);
    }

    //DELETE a company by companyId
    public void deleteById(int companyId) {
        companyRepo.deleteById(companyId);
    }
}
