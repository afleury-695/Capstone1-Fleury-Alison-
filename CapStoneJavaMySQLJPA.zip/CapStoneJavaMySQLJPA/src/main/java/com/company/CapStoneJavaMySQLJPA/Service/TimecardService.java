package com.company.CapStoneJavaMySQLJPA.Service;

import com.company.CapStoneJavaMySQLJPA.Repository.TimecardRepository;
import com.company.CapStoneJavaMySQLJPA.model.Timecard;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TimecardService {
    @Autowired

    private TimecardRepository timecardRepo;


    //adding a new time punch/clockin/transaction to the list
    public Timecard addTimecard(Timecard timecard) {
       timecardRepo.save(timecard);
        return timecard;
    }

    //returns all clock in/out transactions
    public List<Timecard> findAll() {
        return timecardRepo.findAll();
    }

    //gets clock ins/outs by id
    public Timecard getTimecardById(int id) {
        return timecardRepo.getOne(id);
    }

    //this was work alongside setting up the boolean method to change isClockedIn from true to false; this is incomplete/troubleshooting
    /*public void updateTimecard(Timecard timecard, int id, boolean isClockedIn) {
        if(isClockedIn = false) {
            isClockedIn = true;
        }
        timecardRepo.save(timecard);
    }

     */
    //deletes transaction
    public void deleteTimecard(int transactionId) {
        timecardRepo.deleteById(transactionId);
    }

}
