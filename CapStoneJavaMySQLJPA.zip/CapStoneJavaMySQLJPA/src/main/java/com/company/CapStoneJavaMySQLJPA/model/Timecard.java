package com.company.CapStoneJavaMySQLJPA.model;

import java.util.List;

import com.company.CapStoneJavaMySQLJPA.Repository.EmployeeRepository;
import com.company.CapStoneJavaMySQLJPA.model.Employee;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="timecard")

//the entry / exist "timecard" class to keep track of each entry and exit.
public class Timecard {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "transaction_id")
    //the induvidual transaction number (to ensure that employees could have more than one entry/exit log
    private int transactionId;

    //the id number of the employee
    @NotNull
    @Column(name = "id")
    private int id;

    //The time of the clock-in
    @NotNull
    @Column(name = "tcurrent_time")
    private int currentTime;

    /*this boolean is created to run a method set itself to true if its default setting, false, is currently false on run.  This shows that if someone is clocked in, it will read "true"
    as they have clocked in, and false when they clock out, keeping track of entries/exits.  The logic on this was added but commented out as is still in troubleshooting mode.
     */
    @Column(name = "is_clocked_in")
    @NotNull
    private boolean isClockedIn = false;

    //constructor
    public Timecard() {
        this.transactionId = transactionId;
        this.id = id;
        this.currentTime = currentTime;
        this.isClockedIn = isClockedIn;
    }

    //getters and setters
    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //method work for setting up isClockedIn
    public boolean getIsClockedin(boolean isClockedIn) {
        if(isClockedIn = true) {
            isClockedIn = false; }
        return isClockedIn;
    }

    public void setIsClockedin(boolean isClockedIn) {
        this.isClockedIn = isClockedIn;
    }

    public int getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(int currentTime) {
        this.currentTime = currentTime;
    }

}
