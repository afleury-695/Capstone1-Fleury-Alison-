package com.company.CapStoneJavaMySQLJPA.ControllersResource;

import com.company.CapStoneJavaMySQLJPA.Service.TimecardService;
import com.company.CapStoneJavaMySQLJPA.model.Timecard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class TimeCardController {
    @Autowired

    private TimecardService service;

    //posts a new clock in/out transaction to the transaction list
    @RequestMapping(value="/clockin", method= RequestMethod.POST)
    public Timecard addTimecard(@RequestBody @Valid Timecard timecard) {
            service.addTimecard(timecard);
        return timecard;
    }

    //returns all posted transactions
    @RequestMapping(value = "/transactions", method = RequestMethod.GET)
    public List<Timecard> findAll() {
        return service.findAll();
    }

    //finds a transaction by transactionId
    @RequestMapping(value = "/transaction/{id}", method = RequestMethod.GET)
    public Timecard getTimecardById(@PathVariable Integer id) {
        return service.getTimecardById(id);
    }

    //deletes a transaction by transactionId
    @RequestMapping(value = "/timecarddelete/{transactionId}", method = RequestMethod.DELETE)
    public void deleteTimecard(@PathVariable int transactionId) {
        service.deleteTimecard(transactionId);
    }


}

