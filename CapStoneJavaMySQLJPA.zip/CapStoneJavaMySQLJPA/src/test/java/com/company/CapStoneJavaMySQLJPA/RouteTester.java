package com.company.CapStoneJavaMySQLJPA;

//employee mockito
//had to comment out mockito tests as they are still troubleshooting --major issue is calling some static methods from non static, just needs a little more time looking through but they do exist here

/*
import com.company.CapStoneJavaMySQLJPA.Repository.EmployeeRepository;
import com.company.CapStoneJavaMySQLJPA.Service.Service;
import com.company.CapStoneJavaMySQLJPA.model.Employee;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RouteTester {
    @Mock
    EmployeeRepository employeeRepositoryMock;

    @InjectMocks
    Service employeeService = new Service(employeeRepositoryMock);

    Employee employee1;
    Employee employee2;
    Employee employee3;


    List<Employee> employeeList;

    @Before
    public void setUp() {
        employee1 = new Employee(70, "Ben Morton", "Jr. Developer", "June 2009", 7, 4, 7, 1);
        employee2= new Employee((71, "Kendra Test", "Jr. Developer", "June 2010", 7, 4, 7, 1);
        employee3 = new Employee((72, "Ben Morton", "Sr. Developer", "June 2009", 7, 4, 7, 1);

        employeeList = Arrays.asList(employee1, employee2, employee3);
    }

    @Test
    public void testGetAllEmployees() {
        List<Employee> expectedList = Arrays.asList(employee1, employee2);
        when(employeeRepositoryMock.getEmployeeById(1)).thenReturn(employeeList);
        assertEquals(expectedList, Service.getEmployeeById(70, "Ben Morton"));
        //still need to finish other methods here
    }

}

 */


