package com.company.CapStoneJavaMySQLJPA;
//import hibernate.test.oneToMany.joinTable.Employee;
//import hibernate.test.oneToMany.joinTable.Company;

/*import com.company.CapStoneJavaMySQLJPA.model.Company;
import com.company.CapStoneJavaMySQLJPA.model.Employee;
import com.company.CapStoneJavaMySQLJPA.model.Timecard;

 */
//import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CapStoneJavaMySqljpaApplicationTests {

	@Test
	public void contextLoads() {
	}

	//I wasn't able to finish getting all of these tests to run-- they caused the program itself to quit running even when things returned properly in postman
	//as a result I've commented them out for now while I troubleshoot them
	//some are incomplete as I was writing some code elsewhere

	//setting up the objects to test
	/*@Before
	public void setUp() {
		Employee employeetest = new Employee(70, "Ben Morton", "Jr. Developer", "June 2009", 7, 4, 7, 1);
		Company companytest = new Company(99, "The New Company", "Floor Fake");
		Timecard timecardtest = new Timecard(745, 14, 8, true);
	}


//testing the setting of new variables
	@Test
	Public void testAddingVariables() {

	//employee setting
	assertEquals(“Ben Morton”, employeetest.getName(“Ben Morton”));
	assertEquals(70, employeetest.getId(70));

	//company setting
	assertEquals(“The New Company”, companytest.getCompanyName(“The New Company”));
	assertEquals(99, companytest.getCompanyId(99));

	//timecard setting
	assertEquals(745, timecardtest.getTransactionId(745));
	assertEquals(true, timecardtest.getisClockedIn(true));
	}

	 */
	//test code for finding all employees - incomplete for troubleshooting
	/*@Test
	public void shouldFindAllEmployees() {

	}
}
	//tests the method clockIn to assert whether or not the boolean isClockedIn on timecard toggles true/false
	//NOT complete
     public void shouldClockInOrOut() {
     	clockIn();
     	assertTrue(employee.clockIn()) }
	 */
}


