package com.company.CapStoneJavaMySQLJPA;

//had to comment out mockito tests as they are still troubleshooting --major issue is calling some static methods from non static, just needs a little more time looking through but they do exist here
/*
import com.company.CapStoneJavaMySQLJPA.Repository.EmployeeRepository;
import com.company.CapStoneJavaMySQLJPA.Repository.TimecardRepository;
import com.company.CapStoneJavaMySQLJPA.Service.Service;
import com.company.CapStoneJavaMySQLJPA.Service.TimecardService;
import com.company.CapStoneJavaMySQLJPA.model.Timecard;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.Time;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TimeCardTesterMockito {

    @Mock
    TimecardRepository timecardRepositoryMock;

    @InjectMocks
    TimecardService timecardService = new TimecardService(timecardRepositoryMock);


    Timecard timecard1;
    Timecard timecard2;
    Timecard timecard3;


    List<Timecard> timecardList;

    @Before
    public void setUp() {
        timecard1 = new Timecard(745, 14, 8, true);
        timecard2= new Timecard(746, 14, 8, false);
        timecard3 = new Timecard(747, 71 , 8, true);

        timecardList = Arrays.asList(timecard1, timecard2, timecard3);
    }

    @Test
    public void testGetAllEmployees() {
        List<Timecard> expectedList = Arrays.asList(timecard1, timecard2);
        when(timecardRepositoryMock.getTimecardById(1)).thenReturn(timecardList);
        assertEquals(expectedList, TimecardService.getTimecardById(747, 71));
        //still need to finish other methods here --troubleshooting on static v non static method
    }

}

 */
