package com.company.CapStoneJavaMySQLJPA;

//had to comment out mockito tests as they are still troubleshooting --major issue is calling some static methods from non static, just needs a little more time looking through but they do exist here

/*
import com.company.CapStoneJavaMySQLJPA.Repository.CompanyRepository;
import com.company.CapStoneJavaMySQLJPA.Repository.EmployeeRepository;
import com.company.CapStoneJavaMySQLJPA.Repository.TimecardRepository;
import com.company.CapStoneJavaMySQLJPA.Service.CompanyService;
import com.company.CapStoneJavaMySQLJPA.Service.Service;
import com.company.CapStoneJavaMySQLJPA.Service.TimecardService;
import com.company.CapStoneJavaMySQLJPA.model.Company;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentMap;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CompanyTesterMockito {

    @Mock
    CompanyRepository companyRepositoryMock;

    @InjectMocks
    CompanyService companyService = new CompanyService(companyRepositoryMock);

    Company company1;
    Company company2;
    Company company3;

    List<Company> companyList;

    @Before
    public void setUp() {
        company1 = new Company(99, "The New Company", "Floor Fake");
        company2 = new Company(100, "The Other New Company", "Floor ^17");
        company3 = new Company(101, "Testor 3", "Floor 18");

       companyList = Arrays.asList(company1, company2, company3);
    }

    @Test
    public void testGetAllCompanies() {
        List<Company> expectedList = Arrays.asList(company1, company2);
        when(companyRepositoryMock.getCompany(1)).thenReturn(companyList);
        assertEquals(expectedList, companyService.searchById(101, "Testor 3"));
    }

}



 */